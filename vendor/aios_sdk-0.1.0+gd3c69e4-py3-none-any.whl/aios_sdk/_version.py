__version__ = "0.1.0"
SUPPORTED_API_MAJOR = 1
