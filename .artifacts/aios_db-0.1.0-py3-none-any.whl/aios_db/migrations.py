"""Forward/backward migration execution over plain SQL files.

Migrations are files in one directory, named ``NNNN_slug.up.sql`` with a
matching ``NNNN_slug.down.sql``. Which tables they create, which roles they
grant to, what the schema means -- none of that is this library's business. It
owns four properties, and nothing else:

*Serialization.* Every run takes a session-level advisory lock before it reads
the ledger. Two servers starting at the same moment -- the normal case for a
rolling deploy -- would otherwise both read "0001 not applied" and both try to
create the same tables; the second fails mid-DDL and the operator diagnoses a
crash loop instead of a queued migration.

*Atomicity.* Each migration and its ledger row are written in one transaction,
so an interrupted run leaves either the old schema or the new one, never a
half-applied schema that claims to be complete. PostgreSQL's transactional DDL
is what makes this possible; it is why the ledger row is not a separate write
after the fact.

*History integrity.* The checksum of every applied migration is verified against
the file before anything new is applied. Editing an applied migration is the
quiet way to make two environments disagree about what their schema is while
both report the same version.

*Reversibility.* Down-migrations are required, not optional. A downgrade path
that is never executed is a downgrade path that does not work.

Discovery and checksums are pure Python and need no driver; only the execution
functions touch a connection.
"""

from __future__ import annotations

import hashlib
import logging
import re
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ._session import require_autocommit
from .advisory_lock import advisory_lock, lock_key
from .errors import MigrationChecksumMismatch, MigrationError

if TYPE_CHECKING:  # pragma: no cover - import-time typing only
    import psycopg

__all__ = ["DEFAULT_LEDGER_TABLE", "Migration", "MigrationRunner", "discover"]

_LOG = logging.getLogger(__name__)

DEFAULT_LEDGER_TABLE = "schema_migration"

_NAME_RE = re.compile(r"^(?P<version>\d{4})_(?P<slug>[a-z0-9_]+)\.(?P<direction>up|down)\.sql$")

# An identifier cannot be a bound parameter, so the ledger table name is
# composed into every statement through ``psycopg.sql.Identifier``, which quotes
# and escapes it. This pattern is the second layer, not the only one: it keeps
# the name a plain lower-case identifier an operator can type in ``psql``
# without quoting, and rejects a nonsense name at construction time rather than
# at the first statement.
_IDENTIFIER_RE = re.compile(r"^[a-z_][a-z0-9_]{0,62}$")


@dataclass(frozen=True, slots=True)
class Migration:
    """One reversible migration: an up file, its down file, and its identity."""

    version: int
    slug: str
    up_path: Path
    down_path: Path

    @property
    def name(self) -> str:
        return f"{self.version:04d}_{self.slug}"

    @property
    def up_sql(self) -> str:
        return self.up_path.read_text(encoding="utf-8")

    @property
    def down_sql(self) -> str:
        return self.down_path.read_text(encoding="utf-8")

    @property
    def checksum(self) -> str:
        """SHA-256 of the up-migration's bytes, as recorded in the ledger."""
        return hashlib.sha256(self.up_sql.encode("utf-8")).hexdigest()


def discover(sql_dir: Path) -> tuple[Migration, ...]:
    """Load the migration set from ``sql_dir``, oldest first.

    Rejects anything that would make the applied order ambiguous or a downgrade
    wrong: unparseable names, duplicate versions in either direction, a down
    file with no up file, a mismatched slug, a missing down file, and gaps in
    the version sequence.
    """
    if not sql_dir.is_dir():
        raise MigrationError(f"migration directory does not exist: {sql_dir}")

    ups: dict[int, tuple[str, Path]] = {}
    downs: dict[int, Path] = {}

    for path in sorted(sql_dir.glob("*.sql")):
        match = _NAME_RE.match(path.name)
        if match is None:
            raise MigrationError(
                f"{path.name!r} does not match NNNN_slug.(up|down).sql; migration "
                "files are ordered by name, so an unparseable name would be applied "
                "in an undefined position."
            )
        version = int(match["version"])
        if match["direction"] == "up":
            if version in ups:
                raise MigrationError(f"duplicate up-migration for version {version}")
            ups[version] = (match["slug"], path)
        else:
            # Validated as strictly as the up-migrations: an unnoticed duplicate
            # silently overwrites the other, and a downgrade would then run the
            # wrong file against a schema it does not match.
            if version in downs:
                raise MigrationError(f"duplicate down-migration for version {version}")
            downs[version] = path

    orphans = sorted(set(downs) - set(ups))
    if orphans:
        raise MigrationError(
            f"down-migration(s) {orphans} have no matching up-migration; a stray "
            "down file would otherwise be silently ignored, or paired with a "
            "differently named up-migration of the same version"
        )

    migrations: list[Migration] = []
    for version in sorted(ups):
        slug, up_path = ups[version]
        down_path = downs.get(version)
        if down_path is None:
            raise MigrationError(
                f"migration {version:04d}_{slug} has no down-migration; every "
                "migration must be reversible under test"
            )
        if down_path.name != f"{version:04d}_{slug}.down.sql":
            raise MigrationError(
                f"migration {version:04d}_{slug} is paired with {down_path.name!r}; "
                "the up- and down-migration slugs must match"
            )
        migrations.append(
            Migration(version=version, slug=slug, up_path=up_path, down_path=down_path)
        )

    expected = list(range(1, len(migrations) + 1))
    if [m.version for m in migrations] != expected:
        raise MigrationError(
            "migration versions must be contiguous from 0001; got "
            f"{[m.version for m in migrations]}"
        )
    return tuple(migrations)


class MigrationRunner:
    """Applies and reverts a migration set against one database.

    One runner per migration set. The advisory-lock namespace defaults to the
    ledger table name so two independent schemas managed in the same database --
    an application's and a job queue's, say -- serialise separately rather than
    blocking each other.
    """

    def __init__(
        self,
        sql_dir: Path,
        *,
        ledger_table: str = DEFAULT_LEDGER_TABLE,
        lock_namespace: str | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        if not _IDENTIFIER_RE.match(ledger_table):
            raise MigrationError(
                f"ledger table name {ledger_table!r} is not a plain lower-case SQL "
                "identifier; the name is interpolated into DDL and cannot be a "
                "bound parameter"
            )
        self._sql_dir = sql_dir
        self._ledger_table = ledger_table
        self._lock_key = lock_key(lock_namespace or f"aios-db:migrations:{ledger_table}")
        self._log = logger or _LOG

    @property
    def ledger_table(self) -> str:
        return self._ledger_table

    @property
    def lock_key(self) -> int:
        return self._lock_key

    def discover(self) -> tuple[Migration, ...]:
        """The migration set on disk, validated."""
        return discover(self._sql_dir)

    def _sql(self, template: str) -> Any:
        """Compose ``template`` with the ledger table name as a quoted identifier.

        ``{}`` in the template is the ledger table. Composition rather than
        string formatting: an identifier cannot be a bound parameter, and
        ``Identifier`` is the driver's own escaping, so no statement in this
        module is ever assembled by interpolating a name into SQL text.
        """
        from psycopg import sql

        return sql.SQL(template).format(sql.Identifier(self._ledger_table))

    def ensure_ledger(self, conn: psycopg.Connection) -> None:
        """Create the ledger table if absent. Requires DDL rights."""
        conn.execute(
            self._sql(
                "CREATE TABLE IF NOT EXISTS {} ("
                "    version     integer PRIMARY KEY,"
                "    slug        text        NOT NULL,"
                "    checksum    text        NOT NULL,"
                "    applied_at  timestamptz NOT NULL DEFAULT now(),"
                "    applied_by  text        NOT NULL DEFAULT current_user"
                ")"
            )
        )

    def applied_versions(self, conn: psycopg.Connection) -> tuple[int, ...]:
        """Versions recorded as applied, oldest first.

        Read-only on purpose: a readiness probe runs this as the least-privileged
        application role, which has no DDL rights, so creating the ledger here
        would turn a health check into a permission error.
        """
        rows = conn.execute(self._sql("SELECT version FROM {} ORDER BY version")).fetchall()
        return tuple(int(row[0]) for row in rows)

    def current_version(self, conn: psycopg.Connection) -> int:
        """Highest applied version, or ``0`` on a database with an empty ledger."""
        versions = self.applied_versions(conn)
        return versions[-1] if versions else 0

    def upgrade(
        self,
        conn: psycopg.Connection,
        *,
        target: int | None = None,
        lock_wait_timeout: float | None = None,
    ) -> tuple[int, ...]:
        """Apply every pending migration up to ``target``. Returns what was applied."""
        self._require_autocommit(conn)
        if target is not None and target < 0:
            # Otherwise it applies nothing and returns `()`, which is exactly
            # what "already up to date" returns -- a typo reads as success.
            raise MigrationError(f"upgrade target must be >= 0; got {target}")
        migrations = self.discover()
        ceiling = migrations[-1].version if target is None else target

        with advisory_lock(conn, self._lock_key, wait_timeout=lock_wait_timeout):
            self.ensure_ledger(conn)
            already = set(self.applied_versions(conn))
            # A database ahead of this build is not "up to date" -- it is a
            # rollback nobody noticed. Reporting it stops an old deploy from
            # running happily against a newer schema.
            ahead = sorted(already - {m.version for m in migrations})
            if ahead:
                raise MigrationError(
                    f"database has migration(s) {ahead} applied that this build does "
                    "not define; it was migrated by a newer deploy, so roll the code "
                    "forward rather than migrating backwards"
                )
            self.verify_checksums(conn, migrations)
            applied: list[int] = []
            for migration in migrations:
                if migration.version in already or migration.version > ceiling:
                    continue
                self._log.info("applying migration %s", migration.name)
                with conn.transaction():
                    conn.execute(migration.up_sql)
                    conn.execute(
                        self._sql("INSERT INTO {} (version, slug, checksum) VALUES (%s, %s, %s)"),
                        (migration.version, migration.slug, migration.checksum),
                    )
                applied.append(migration.version)
            return tuple(applied)

    def downgrade(
        self,
        conn: psycopg.Connection,
        *,
        target: int,
        lock_wait_timeout: float | None = None,
    ) -> tuple[int, ...]:
        """Revert applied migrations down to (and including) every version above ``target``."""
        self._require_autocommit(conn)
        if target < 0:
            raise MigrationError(f"downgrade target must be >= 0; got {target}")
        migrations = {m.version: m for m in self.discover()}

        with advisory_lock(conn, self._lock_key, wait_timeout=lock_wait_timeout):
            self.ensure_ledger(conn)
            applied = self.applied_versions(conn)
            undefined = sorted(version for version in applied if version not in migrations)
            if undefined:
                raise MigrationError(
                    f"database has migration(s) {undefined} applied but no file defines "
                    "them; refusing to guess how to revert them"
                )
            # Verified here as well as in `upgrade`: reverting with a file that
            # no longer matches what was applied runs the wrong SQL against the
            # schema, and does so in the destructive direction.
            self.verify_checksums(conn, list(migrations.values()))
            reverted: list[int] = []
            for version in sorted(applied, reverse=True):
                if version <= target:
                    break
                migration = migrations[version]
                self._log.info("reverting migration %s", migration.name)
                with conn.transaction():
                    conn.execute(migration.down_sql)
                    conn.execute(
                        self._sql("DELETE FROM {} WHERE version = %s"), (version,)
                    )
                reverted.append(version)
            return tuple(reverted)

    def verify_checksums(
        self,
        conn: psycopg.Connection,
        migrations: Sequence[Migration] | None = None,
    ) -> None:
        """Fail if the ledger disagrees with the migration set on disk.

        Two disagreements, both of which mean the database is not the schema
        this build thinks it is: an applied migration whose file has been edited
        since, and an applied version this build does not define at all.
        """
        known = list(migrations if migrations is not None else self.discover())
        by_version = {m.version: m for m in known}
        rows = conn.execute(
            self._sql("SELECT version, checksum FROM {} ORDER BY version")
        ).fetchall()
        ahead = sorted(int(version) for version, _ in rows if int(version) not in by_version)
        if ahead:
            # Checked here and not only in `upgrade` so a readiness composition
            # that calls this directly cannot report a database migrated by a
            # newer deploy as healthy.
            raise MigrationError(
                f"database has migration(s) {ahead} applied that this build does "
                "not define; it was migrated by a newer deploy, so roll the code "
                "forward rather than migrating backwards"
            )
        for version, checksum in rows:
            migration = by_version.get(int(version))
            if migration is None:  # pragma: no cover - excluded by the check above
                continue
            if migration.checksum != checksum:
                raise MigrationChecksumMismatch(
                    f"migration {migration.name} was modified after it was applied "
                    f"(recorded {str(checksum)[:12]}…, file {migration.checksum[:12]}…); "
                    "add a new migration instead of editing an applied one"
                )

    def _require_autocommit(self, conn: psycopg.Connection) -> None:
        require_autocommit(
            conn,
            "the migration runner requires an autocommit connection: per-migration "
            "atomicity and advisory-lock release both depend on it. Open the "
            "connection with autocommit=True, or open the pool with "
            "aios_db.open_pool(..., autocommit=True).",
            MigrationError,
        )
