"""Connection-pool lifecycle for PostgreSQL.

A pool rather than connect-per-query because PostgreSQL forks a backend process
per connection: at any real request rate, connecting per query spends more time
forking backends than running statements, and an unbounded connection count is
the ordinary way to take a PostgreSQL server down.

The one behaviour this module exists to guarantee is that **opening is
verified**. ``ConnectionPool(..., open=True)`` starts the pool's background
workers and returns immediately; it does not prove that a connection can be
established. A process that opens a pool that way and only discovers a bad DSN,
an unreachable host or a rejected certificate on its first request has moved a
startup failure -- which an operator sees, and which a deployment can roll back
-- into a request failure, which looks like an application bug. :func:`open_pool`
waits for the first connections and closes the half-built pool before
propagating, so a failed open leaks neither sockets nor worker threads.

Process-wide pool ownership (a module singleton, a lifespan-scoped attribute)
is deliberately *not* decided here: that is the consuming application's
composition concern, and a library that hides a global makes two applications in
one process impossible to reason about.
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

from .errors import PoolError

if TYPE_CHECKING:  # pragma: no cover - import-time typing only
    import psycopg
    from psycopg_pool import ConnectionPool

__all__ = ["connection", "open_pool", "pool_stats"]


def _pool_class() -> type[ConnectionPool]:
    """The pool implementation :func:`open_pool` instantiates.

    Resolved through a function so the driver is imported lazily -- this package
    stays importable for its pure-Python migration discovery on a machine with
    no ``psycopg`` -- and so a unit test can substitute a double for the paths
    that must be provable without a database (sizing validation, and that a
    failed open closes the half-built pool).
    """
    from psycopg_pool import ConnectionPool

    return ConnectionPool


def open_pool(
    conninfo: str,
    *,
    min_size: int = 1,
    max_size: int = 10,
    timeout: float = 10.0,
    checkout_timeout: float | None = None,
    name: str | None = None,
    autocommit: bool | None = None,
    connection_kwargs: dict[str, Any] | None = None,
) -> ConnectionPool:
    """Open a pool and prove it can reach the database before returning.

    ``timeout`` bounds the wait for the first connections — a startup concern.
    ``checkout_timeout`` bounds how long ``pool.connection()`` later waits for a
    free connection under load — a runtime concern with a different right
    answer, which is why it is a separate knob rather than the same number
    reused. Left ``None``, psycopg's own default applies.

    ``autocommit`` selects the transaction mode of every pooled connection.
    Leave it ``None`` to keep psycopg's default (an implicit transaction opened
    before the first statement); pass ``True`` for callers -- the migration
    runner among them -- whose guarantees depend on statements being individually
    durable. It is expressed here rather than left to the call site because a
    pool that mixes modes across checkouts is not debuggable.

    Raises :class:`~aios_db.errors.PoolError` if the pool cannot be opened.
    """
    if min_size < 0 or max_size < 1 or max_size < min_size:
        raise PoolError(
            "invalid pool sizing: expected 0 <= min_size <= max_size and max_size >= 1"
        )

    kwargs: dict[str, Any] = dict(connection_kwargs or {})
    if autocommit is not None:
        kwargs["autocommit"] = autocommit

    sizing: dict[str, Any] = {}
    if checkout_timeout is not None:
        sizing["timeout"] = checkout_timeout

    pool = _pool_class()(
        conninfo=conninfo,
        min_size=min_size,
        max_size=max_size,
        **sizing,
        kwargs=kwargs,
        name=name,
        # Opened below rather than here so a failure to connect is *this*
        # call's failure, with the half-built pool already cleaned up.
        open=False,
    )
    try:
        pool.open(wait=True, timeout=timeout)
    except BaseException as exc:
        # Closing on the way out matters for BaseException too: a
        # KeyboardInterrupt or a cancellation during startup would otherwise
        # leave the pool's worker threads running for the life of the process.
        pool.close()
        if isinstance(exc, Exception):
            # The driver's message can carry the host and user from the DSN;
            # keep it as the cause (visible in a traceback an operator reads)
            # without restating it in a message that may be logged or serialised.
            raise PoolError("could not open the PostgreSQL connection pool") from exc
        raise
    return pool


@contextmanager
def connection(pool: ConnectionPool) -> Iterator[psycopg.Connection]:
    """Check a connection out of ``pool`` for the duration of the block.

    A thin, typed alias for ``pool.connection()`` so consumers can depend on this
    library's surface instead of importing ``psycopg_pool`` themselves.
    """
    with pool.connection() as conn:
        yield conn


def pool_stats(pool: ConnectionPool) -> dict[str, int]:
    """The three pool counters a readiness probe or a metric actually uses.

    Restricted to a fixed set of integers on purpose: psycopg's ``get_stats``
    payload is not a stable contract, and probe payloads are commonly
    unauthenticated, so a probe should not forward whatever the driver happens
    to expose in a future version.
    """
    stats = pool.get_stats()
    return {
        "pool_size": int(stats.get("pool_size", 0)),
        "pool_available": int(stats.get("pool_available", 0)),
        "requests_waiting": int(stats.get("requests_waiting", 0)),
    }
