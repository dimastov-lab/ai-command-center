from __future__ import annotations

import traceback
from collections.abc import AsyncIterator, Mapping
from functools import wraps
from typing import Any, Awaitable, Callable, ParamSpec, TypeVar, cast

import httpx

from .client import (
    _expect,
    _idempotency_headers,
    _memory_page,
    _memory_query_params,
    _memory_result,
    _page_arguments,
    _path_id,
    _task_page,
    _task_result,
)
from .config import ClientConfig, CredentialProvider, RetryPolicy
from .errors import ContractError
from .generated.models import (
    CreateMemoryRequest,
    CreateTaskRequest,
    HealthStatus,
    MemoryObject,
    ReadinessStatus,
    Task,
    TaskAssigneeRequest,
    TaskEvent,
    TaskEventListResponse,
    TaskSweepResponse,
    Workspace,
    WorkspaceCreateRequest,
    WorkspaceListResponse,
    WorkspaceResponse,
)
from .pagination import Page, iterate_pages_async
from .transport import APIResponse, AsyncTransport, parse_success

P = ParamSpec("P")
R = TypeVar("R")


def _contract_boundary_async(
    method: Callable[P, Awaitable[R]],
) -> Callable[P, Awaitable[R]]:
    @wraps(method)
    async def guarded(*args: P.args, **kwargs: P.kwargs) -> R:
        safe_error: ContractError | None = None
        try:
            return await method(*args, **kwargs)
        except ContractError as error:
            if error.__traceback__ is not None:
                traceback.clear_frames(error.__traceback__)
            safe_error = ContractError(
                str(error),
                status_code=error.status_code,
                request_id=error.request_id,
                code=error.code,
                validation_summary=error.validation_summary,
            )
        assert safe_error is not None
        raise safe_error

    return cast(Callable[P, Awaitable[R]], guarded)


class AsyncWorkspacesAPI:
    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    @_contract_boundary_async
    async def create(
        self, request: WorkspaceCreateRequest, *, request_id: str | None = None
    ) -> APIResponse[Workspace]:
        response = await self._transport.request(
            "POST",
            "/api/v1/workspaces",
            auth=True,
            json=request.model_dump(mode="json", exclude_none=True),
            request_id=request_id,
        )
        _expect(response, {201})
        wrapped = parse_success(response, WorkspaceResponse)
        return APIResponse(
            wrapped.data.data,
            wrapped.request_id,
            wrapped.status_code,
            wrapped.etag,
            wrapped.retry_after,
        )

    @_contract_boundary_async
    async def get(
        self, workspace_id: str, *, request_id: str | None = None
    ) -> APIResponse[Workspace]:
        response = await self._transport.request(
            "GET",
            f"/api/v1/workspaces/{_path_id(workspace_id)}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        wrapped = parse_success(response, WorkspaceResponse)
        return APIResponse(
            wrapped.data.data,
            wrapped.request_id,
            wrapped.status_code,
            wrapped.etag,
            wrapped.retry_after,
        )

    @_contract_boundary_async
    async def list(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        request_id: str | None = None,
    ) -> Page[Workspace]:
        _page_arguments(limit, cursor)
        params: dict[str, str | int | float | bool | None] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        response = await self._transport.request(
            "GET",
            "/api/v1/workspaces",
            auth=True,
            params=params,
            request_id=request_id,
        )
        _expect(response, {200})
        wrapped = parse_success(response, WorkspaceListResponse)
        return Page(
            wrapped.data.data,
            wrapped.data.page.next_cursor,
            wrapped.data.page.has_more,
            wrapped.request_id,
            wrapped.status_code,
        )

    def iterate(
        self, *, limit: int = 50, request_id: str | None = None
    ) -> AsyncIterator[Workspace]:
        _page_arguments(limit, None)
        return iterate_pages_async(
            lambda cursor: self.list(limit=limit, cursor=cursor, request_id=request_id)
        )


class AsyncMemoriesAPI:
    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    @_contract_boundary_async
    async def create_in_workspace(
        self,
        workspace_id: str,
        request: CreateMemoryRequest,
        *,
        idempotency_key: str | None = None,
        request_id: str | None = None,
    ) -> APIResponse[MemoryObject]:
        response = await self._transport.request(
            "POST",
            f"/api/v1/workspaces/{_path_id(workspace_id)}/memories",
            auth=True,
            json=request.model_dump(mode="json", exclude_none=True),
            extra_headers=_idempotency_headers(idempotency_key),
            request_id=request_id,
        )
        _expect(response, {200, 201})
        return _memory_result(response)

    @_contract_boundary_async
    async def create_global(
        self,
        request: CreateMemoryRequest,
        *,
        idempotency_key: str | None = None,
        request_id: str | None = None,
    ) -> APIResponse[MemoryObject]:
        response = await self._transport.request(
            "POST",
            "/api/v1/global/memories",
            auth=True,
            json=request.model_dump(mode="json", exclude_none=True),
            extra_headers=_idempotency_headers(idempotency_key),
            request_id=request_id,
        )
        _expect(response, {200, 201})
        return _memory_result(response)

    @_contract_boundary_async
    async def get_in_workspace(
        self, workspace_id: str, memory_id: str, *, request_id: str | None = None
    ) -> APIResponse[MemoryObject]:
        response = await self._transport.request(
            "GET",
            f"/api/v1/workspaces/{_path_id(workspace_id)}/memories/{_path_id(memory_id)}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        return _memory_result(response)

    @_contract_boundary_async
    async def get_global(
        self, memory_id: str, *, request_id: str | None = None
    ) -> APIResponse[MemoryObject]:
        response = await self._transport.request(
            "GET",
            f"/api/v1/global/memories/{_path_id(memory_id)}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        return _memory_result(response)

    @_contract_boundary_async
    async def list_in_workspace(
        self,
        workspace_id: str,
        *,
        limit: int = 50,
        cursor: str | None = None,
        kind: str | None = None,
        status: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        text: str | None = None,
        order: str | None = None,
        include_global: bool | None = None,
        request_id: str | None = None,
    ) -> Page[MemoryObject]:
        _page_arguments(limit, cursor)
        params = _memory_query_params(
            limit=limit,
            cursor=cursor,
            kind=kind,
            status=status,
            created_after=created_after,
            created_before=created_before,
            text=text,
            order=order,
        )
        if include_global is not None:
            params["include_global"] = include_global
        response = await self._transport.request(
            "GET",
            f"/api/v1/workspaces/{_path_id(workspace_id)}/memories",
            auth=True,
            params=params,
            request_id=request_id,
        )
        _expect(response, {200})
        return _memory_page(response)

    @_contract_boundary_async
    async def list_global(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        kind: str | None = None,
        status: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        text: str | None = None,
        order: str | None = None,
        request_id: str | None = None,
    ) -> Page[MemoryObject]:
        _page_arguments(limit, cursor)
        params = _memory_query_params(
            limit=limit,
            cursor=cursor,
            kind=kind,
            status=status,
            created_after=created_after,
            created_before=created_before,
            text=text,
            order=order,
        )
        response = await self._transport.request(
            "GET",
            "/api/v1/global/memories",
            auth=True,
            params=params,
            request_id=request_id,
        )
        _expect(response, {200})
        return _memory_page(response)


class AsyncTasksAPI:
    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    @_contract_boundary_async
    async def create(
        self,
        request: CreateTaskRequest,
        *,
        idempotency_key: str | None = None,
        request_id: str | None = None,
    ) -> APIResponse[Task]:
        response = await self._transport.request(
            "POST",
            "/api/v1/tasks",
            auth=True,
            json=request.model_dump(mode="json", exclude_none=True),
            extra_headers=_idempotency_headers(idempotency_key),
            request_id=request_id,
        )
        # 201 = created, 200 = idempotent replay of the original task --
        # callers distinguish via `status_code`, as with memory creates.
        _expect(response, {200, 201})
        return _task_result(response)

    @_contract_boundary_async
    async def get(
        self, task_id: str, *, request_id: str | None = None
    ) -> APIResponse[Task]:
        response = await self._transport.request(
            "GET",
            f"/api/v1/tasks/{_path_id(task_id)}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        return _task_result(response)

    @_contract_boundary_async
    async def list(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        request_id: str | None = None,
    ) -> Page[Task]:
        _page_arguments(limit, cursor)
        params: dict[str, str | int | float | bool | None] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        response = await self._transport.request(
            "GET",
            "/api/v1/tasks",
            auth=True,
            params=params,
            request_id=request_id,
        )
        _expect(response, {200})
        return _task_page(response)

    def iterate(
        self, *, limit: int = 50, request_id: str | None = None
    ) -> AsyncIterator[Task]:
        _page_arguments(limit, None)
        return iterate_pages_async(
            lambda cursor: self.list(limit=limit, cursor=cursor, request_id=request_id)
        )

    @_contract_boundary_async
    async def list_events(
        self, task_id: str, *, request_id: str | None = None
    ) -> APIResponse[tuple[TaskEvent, ...]]:
        response = await self._transport.request(
            "GET",
            f"/api/v1/tasks/{_path_id(task_id)}/events",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        wrapped = parse_success(response, TaskEventListResponse)
        return APIResponse(
            wrapped.data.data,
            wrapped.request_id,
            wrapped.status_code,
            wrapped.etag,
            wrapped.retry_after,
        )

    @_contract_boundary_async
    async def assign(
        self, task_id: str, assignee: str, *, request_id: str | None = None
    ) -> APIResponse[Task]:
        return await self._assignee_action(task_id, "assign", assignee, request_id)

    @_contract_boundary_async
    async def reassign(
        self, task_id: str, assignee: str, *, request_id: str | None = None
    ) -> APIResponse[Task]:
        return await self._assignee_action(task_id, "reassign", assignee, request_id)

    @_contract_boundary_async
    async def start(
        self, task_id: str, *, request_id: str | None = None
    ) -> APIResponse[Task]:
        return await self._action(task_id, "start", request_id)

    @_contract_boundary_async
    async def complete(
        self, task_id: str, *, request_id: str | None = None
    ) -> APIResponse[Task]:
        return await self._action(task_id, "complete", request_id)

    @_contract_boundary_async
    async def cancel(
        self, task_id: str, *, request_id: str | None = None
    ) -> APIResponse[Task]:
        return await self._action(task_id, "cancel", request_id)

    @_contract_boundary_async
    async def escalate(
        self, task_id: str, *, request_id: str | None = None
    ) -> APIResponse[Task]:
        return await self._action(task_id, "escalate", request_id)

    @_contract_boundary_async
    async def sweep_due(
        self, *, request_id: str | None = None
    ) -> APIResponse[tuple[Task, ...]]:
        response = await self._transport.request(
            "POST",
            "/api/v1/tasks/sweep-due",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        wrapped = parse_success(response, TaskSweepResponse)
        return APIResponse(
            wrapped.data.data,
            wrapped.request_id,
            wrapped.status_code,
            wrapped.etag,
            wrapped.retry_after,
        )

    async def _action(
        self, task_id: str, action: str, request_id: str | None
    ) -> APIResponse[Task]:
        response = await self._transport.request(
            "POST",
            f"/api/v1/tasks/{_path_id(task_id)}/{action}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        return _task_result(response)

    async def _assignee_action(
        self, task_id: str, action: str, assignee: str, request_id: str | None
    ) -> APIResponse[Task]:
        body = TaskAssigneeRequest(assignee=assignee)
        response = await self._transport.request(
            "POST",
            f"/api/v1/tasks/{_path_id(task_id)}/{action}",
            auth=True,
            json=body.model_dump(mode="json"),
            request_id=request_id,
        )
        _expect(response, {200})
        return _task_result(response)


class AsyncHealthAPI:
    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    @_contract_boundary_async
    async def get(self, *, request_id: str | None = None) -> APIResponse[HealthStatus]:
        response = await self._transport.request(
            "GET", "/healthz", auth=False, request_id=request_id
        )
        _expect(response, {200})
        return parse_success(response, HealthStatus)


class AsyncReadinessAPI:
    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    @_contract_boundary_async
    async def get(self, *, request_id: str | None = None) -> APIResponse[ReadinessStatus]:
        response = await self._transport.request(
            "GET", "/readyz", auth=False, request_id=request_id
        )
        _expect(response, {200, 503}, error_statuses={500})
        return parse_success(response, ReadinessStatus)


class AsyncAIOSClient:
    def __init__(
        self,
        base_url: str,
        *,
        token: str | None = None,
        credential_provider: CredentialProvider | None = None,
        timeout: httpx.Timeout | None = None,
        retry: RetryPolicy | None = None,
        user_agent: str | None = None,
        default_headers: Mapping[str, str] | None = None,
        verify: bool | str = True,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        config_kwargs: dict[str, Any] = {
            "base_url": base_url,
            "token": token,
            "credential_provider": credential_provider,
            "verify": verify,
        }
        if timeout is not None:
            config_kwargs["timeout"] = timeout
        if retry is not None:
            config_kwargs["retry"] = retry
        if user_agent is not None:
            config_kwargs["user_agent"] = user_agent
        if default_headers is not None:
            config_kwargs["default_headers"] = default_headers
        self.config = ClientConfig(**config_kwargs)
        self._transport = AsyncTransport(self.config, transport=transport)
        self.workspaces = AsyncWorkspacesAPI(self._transport)
        self.memories = AsyncMemoriesAPI(self._transport)
        self.tasks = AsyncTasksAPI(self._transport)
        self.health = AsyncHealthAPI(self._transport)
        self.readiness = AsyncReadinessAPI(self._transport)

    @property
    def is_closed(self) -> bool:
        return self._transport.is_closed

    async def close(self) -> None:
        await self._transport.close()

    async def __aenter__(self) -> AsyncAIOSClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
