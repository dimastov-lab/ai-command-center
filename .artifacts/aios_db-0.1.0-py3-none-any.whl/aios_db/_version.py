"""Version of the independently packaged ``aios-db`` distribution.

Deliberately separate from ``aios.__version__``: the platform and this library
are versioned and pinned independently, so a consumer that pins ``aios-db``
does not inherit a platform release cadence it has no interest in.
"""

from __future__ import annotations

__version__ = "0.1.0"
