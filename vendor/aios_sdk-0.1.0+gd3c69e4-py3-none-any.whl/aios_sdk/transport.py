from __future__ import annotations

import asyncio
import email.utils
import random
import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Generic, Literal, TypeVar

import httpx
from pydantic import BaseModel, ValidationError as PydanticValidationError

from .config import ClientConfig
from .errors import ContractError, TimeoutError, TransportError, exception_type
from .generated.metadata import ERROR_CONTRACT
from .generated.models import ErrorEnvelope, SPECIALIZED_ERROR_MODELS

T = TypeVar("T", bound=BaseModel)
# `APIResponse` is a plain result container: its payload is usually one
# contract model, but collection results (task events, sweep results)
# carry a tuple of models, so its own parameter is deliberately unbounded.
ResultT = TypeVar("ResultT")
MAX_RESPONSE_BYTES = 2 * 1024 * 1024
_JSON_DECODE_FAILED = object()
TransportFailure = Literal["timeout", "transport"]


@dataclass(frozen=True, slots=True)
class _ContractFailure:
    message: str
    status_code: int | None
    request_id: str | None
    code: str | None
    validation_summary: str | None


@dataclass(frozen=True, slots=True)
class APIResponse(Generic[ResultT]):
    data: ResultT
    request_id: str
    status_code: int
    etag: str | None = None
    retry_after: float | None = None


def _safe_sync_send(
    send: Callable[[], httpx.Response],
) -> tuple[httpx.Response | None, TransportFailure | _ContractFailure | None]:
    try:
        return send(), None
    except httpx.TimeoutException:
        return None, "timeout"
    except httpx.TransportError:
        return None, "transport"
    except ContractError as error:
        return None, _contract_failure(error)


async def _safe_async_send(
    send: Callable[[], Awaitable[httpx.Response]],
) -> tuple[httpx.Response | None, TransportFailure | _ContractFailure | None]:
    try:
        return await send(), None
    except httpx.TimeoutException:
        return None, "timeout"
    except httpx.TransportError:
        return None, "transport"
    except ContractError as error:
        return None, _contract_failure(error)


def _contract_failure(error: ContractError) -> _ContractFailure:
    return _ContractFailure(
        str(error),
        error.status_code,
        error.request_id,
        error.code,
        error.validation_summary,
    )


class SyncTransport:
    def __init__(
        self,
        config: ClientConfig,
        *,
        transport: httpx.BaseTransport | None = None,
        sleep: Callable[[float], None] = time.sleep,
        random_value: Callable[[], float] = random.random,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.config = config
        self._sleep = sleep
        self._random = random_value
        self._clock = clock
        self._client = httpx.Client(
            base_url=config.base_url,
            headers={"User-Agent": config.user_agent, **config.default_headers},
            timeout=config.timeout,
            verify=config.verify,
            transport=transport,
        )

    @property
    def is_closed(self) -> bool:
        return self._client.is_closed

    def close(self) -> None:
        self._client.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        auth: bool,
        params: Mapping[str, str | int | float | bool | None] | None = None,
        json: object | None = None,
        request_id: str | None = None,
        extra_headers: Mapping[str, str] | None = None,
    ) -> httpx.Response:
        started = self._clock()
        attempt = 1
        while True:
            response, failure = _safe_sync_send(
                lambda: self._send_bounded(
                    method,
                    path,
                    auth=auth,
                    params=params,
                    json=json,
                    request_id=request_id,
                    extra_headers=extra_headers,
                )
            )
            if failure is not None:
                if isinstance(failure, _ContractFailure):
                    raise ContractError(
                        failure.message,
                        status_code=failure.status_code,
                        request_id=failure.request_id,
                        code=failure.code,
                        validation_summary=failure.validation_summary,
                    )
                error_type = TimeoutError if failure == "timeout" else TransportError
                message = (
                    "request timed out"
                    if failure == "timeout"
                    else "request failed before a response was received"
                )
                if not _can_retry_transport(method, attempt, self.config, started, self._clock):
                    raise error_type(message)
                delay = _bounded_delay(
                    _delay(attempt, self.config, self._random),
                    started,
                    self.config,
                    self._clock,
                )
                if delay is None:
                    raise error_type(message)
                self._sleep(delay)
                attempt += 1
                continue
            assert response is not None
            if not _can_retry_response(
                response, method, attempt, self.config, started, self._clock
            ):
                return response
            delay = _bounded_delay(
                _response_delay(response, attempt, self.config, self._random),
                started,
                self.config,
                self._clock,
            )
            if delay is None:
                return response
            self._sleep(delay)
            attempt += 1

    def _send_bounded(
        self,
        method: str,
        path: str,
        *,
        auth: bool,
        params: Mapping[str, str | int | float | bool | None] | None,
        json: object | None,
        request_id: str | None,
        extra_headers: Mapping[str, str] | None = None,
    ) -> httpx.Response:
        headers = _headers(
            self.config, auth=auth, request_id=request_id, has_json=json is not None
        )
        if extra_headers:
            headers.update(extra_headers)
        try:
            with self._client.stream(
                method, path, params=params, json=json, headers=headers
            ) as response:
                _redact_response_request(response)
                return _read_bounded_response(response)
        finally:
            headers.pop("Authorization", None)


class AsyncTransport:
    def __init__(
        self,
        config: ClientConfig,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
        random_value: Callable[[], float] = random.random,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.config = config
        self._sleep = sleep
        self._random = random_value
        self._clock = clock
        self._client = httpx.AsyncClient(
            base_url=config.base_url,
            headers={"User-Agent": config.user_agent, **config.default_headers},
            timeout=config.timeout,
            verify=config.verify,
            transport=transport,
        )

    @property
    def is_closed(self) -> bool:
        return self._client.is_closed

    async def close(self) -> None:
        await self._client.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        auth: bool,
        params: Mapping[str, str | int | float | bool | None] | None = None,
        json: object | None = None,
        request_id: str | None = None,
        extra_headers: Mapping[str, str] | None = None,
    ) -> httpx.Response:
        started = self._clock()
        attempt = 1
        while True:
            response, failure = await _safe_async_send(
                lambda: self._send_bounded(
                    method,
                    path,
                    auth=auth,
                    params=params,
                    json=json,
                    request_id=request_id,
                    extra_headers=extra_headers,
                )
            )
            if failure is not None:
                if isinstance(failure, _ContractFailure):
                    raise ContractError(
                        failure.message,
                        status_code=failure.status_code,
                        request_id=failure.request_id,
                        code=failure.code,
                        validation_summary=failure.validation_summary,
                    )
                error_type = TimeoutError if failure == "timeout" else TransportError
                message = (
                    "request timed out"
                    if failure == "timeout"
                    else "request failed before a response was received"
                )
                if not _can_retry_transport(method, attempt, self.config, started, self._clock):
                    raise error_type(message)
                delay = _bounded_delay(
                    _delay(attempt, self.config, self._random),
                    started,
                    self.config,
                    self._clock,
                )
                if delay is None:
                    raise error_type(message)
                await self._sleep(delay)
                attempt += 1
                continue
            assert response is not None
            if not _can_retry_response(
                response, method, attempt, self.config, started, self._clock
            ):
                return response
            delay = _bounded_delay(
                _response_delay(response, attempt, self.config, self._random),
                started,
                self.config,
                self._clock,
            )
            if delay is None:
                return response
            await self._sleep(delay)
            attempt += 1

    async def _send_bounded(
        self,
        method: str,
        path: str,
        *,
        auth: bool,
        params: Mapping[str, str | int | float | bool | None] | None,
        json: object | None,
        request_id: str | None,
        extra_headers: Mapping[str, str] | None = None,
    ) -> httpx.Response:
        headers = _headers(
            self.config, auth=auth, request_id=request_id, has_json=json is not None
        )
        if extra_headers:
            headers.update(extra_headers)
        try:
            async with self._client.stream(
                method, path, params=params, json=json, headers=headers
            ) as response:
                _redact_response_request(response)
                return await _read_bounded_response_async(response)
        finally:
            headers.pop("Authorization", None)


def parse_success(response: httpx.Response, model: type[T]) -> APIResponse[T]:
    payload, payload_error = _json_payload(response)
    if payload_error is not None:
        status_code = response.status_code
        request_id = _safe_header_request_id(response)
        del response, payload
        raise ContractError(
            payload_error,
            status_code=status_code,
            request_id=request_id,
        )
    parsed, validation_summary = _safe_validate(model, payload)
    if parsed is None:
        status_code = response.status_code
        request_id = _safe_header_request_id(response)
        del payload, response
        raise ContractError(
            "server response does not match the canonical success schema",
            status_code=status_code,
            request_id=request_id,
            validation_summary=validation_summary,
        )
    request_id = _request_id(response, parsed)
    if request_id is None:
        status_code = response.status_code
        safe_request_id = _safe_header_request_id(response)
        del response, parsed, payload
        raise ContractError(
            "server response has inconsistent X-Request-ID metadata",
            status_code=status_code,
            request_id=safe_request_id,
        )
    return APIResponse(
        parsed,
        request_id=request_id,
        status_code=response.status_code,
        etag=response.headers.get("ETag"),
        retry_after=_retry_after(response),
    )


def raise_for_error(response: httpx.Response) -> None:
    payload, payload_error = _json_payload(response)
    if payload_error is not None:
        status_code = response.status_code
        request_id = _safe_header_request_id(response)
        del response, payload
        raise ContractError(
            payload_error,
            status_code=status_code,
            request_id=request_id,
        )
    envelope, validation_summary = _safe_validate(ErrorEnvelope, payload)
    if envelope is None:
        status_code = response.status_code
        request_id = _safe_header_request_id(response)
        del payload, response
        raise ContractError(
            "server error does not match the canonical error envelope",
            status_code=status_code,
            request_id=request_id,
            validation_summary=validation_summary,
        )
    spec = ERROR_CONTRACT.get(envelope.error.code)
    if not isinstance(spec, dict):
        status_code = response.status_code
        request_id = envelope.meta.request_id
        del payload, envelope, response
        raise ContractError(
            "server returned an unknown canonical error code",
            status_code=status_code,
            request_id=request_id,
        )
    if spec["status"] != response.status_code or spec["retryable"] is not envelope.error.retryable:
        status_code = response.status_code
        request_id = envelope.meta.request_id
        code = envelope.error.code
        del payload, envelope, response
        raise ContractError(
            "server error status or retryability violates the canonical contract",
            status_code=status_code,
            request_id=request_id,
            code=code,
        )
    specialized = SPECIALIZED_ERROR_MODELS[envelope.error.code]
    validated, validation_summary = _safe_validate(specialized, payload)
    if validated is None:
        status_code = response.status_code
        request_id = envelope.meta.request_id
        code = envelope.error.code
        del payload, envelope, response, specialized
        raise ContractError(
            "server error does not match its specialized canonical schema",
            status_code=status_code,
            request_id=request_id,
            code=code,
            validation_summary=validation_summary,
        )
    error = exception_type(envelope.error.code)
    raise error(
        status_code=response.status_code,
        code=envelope.error.code,
        message=envelope.error.message,
        request_id=envelope.meta.request_id,
        retryable=envelope.error.retryable,
        details=envelope.error.details,
        retry_after=_retry_after(response),
    )


def _headers(
    config: ClientConfig, *, auth: bool, request_id: str | None, has_json: bool
) -> dict[str, str]:
    headers: dict[str, str] = {}
    if auth:
        authorization = config.authorization_value()
        if authorization is not None:
            headers["Authorization"] = authorization
    if request_id is not None:
        if not request_id or len(request_id) > 128 or any(
            character not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._:-"
            for character in request_id
        ):
            raise ContractError("request_id does not match the canonical contract")
        headers["X-Request-ID"] = request_id
    if has_json:
        headers["Content-Type"] = "application/json"
    return headers


def _json_payload(response: httpx.Response) -> tuple[Any, str | None]:
    content_type = response.headers.get("Content-Type", "").partition(";")[0].strip().lower()
    if content_type != "application/json":
        return None, "server response is not canonical application/json"
    if len(response.content) > MAX_RESPONSE_BYTES:
        return None, "server response exceeds the SDK safety limit"
    decoded = _safe_decode_json(response)
    if decoded is _JSON_DECODE_FAILED:
        return None, "server returned malformed JSON"
    return decoded, None


def _safe_decode_json(response: httpx.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        return _JSON_DECODE_FAILED


def _safe_validate(model: type[T], payload: Any) -> tuple[T | None, str | None]:
    try:
        return model.model_validate(payload), None
    except PydanticValidationError as error:
        count = error.error_count()
        return None, f"{count} validation error(s)"


def _read_bounded_response(response: httpx.Response) -> httpx.Response:
    if _oversized_content_length(response):
        status_code = response.status_code
        request_id = _safe_header_request_id(response)
        del response
        raise ContractError(
            "server response exceeds the SDK safety limit",
            status_code=status_code,
            request_id=request_id,
        )
    content = bytearray()
    for chunk in response.iter_bytes():
        if len(content) + len(chunk) > MAX_RESPONSE_BYTES:
            status_code = response.status_code
            request_id = _safe_header_request_id(response)
            del chunk, content, response
            raise ContractError(
                "server response exceeds the SDK safety limit",
                status_code=status_code,
                request_id=request_id,
            )
        content.extend(chunk)
    return _detached_response(response, bytes(content))


async def _read_bounded_response_async(response: httpx.Response) -> httpx.Response:
    if _oversized_content_length(response):
        status_code = response.status_code
        request_id = _safe_header_request_id(response)
        del response
        raise ContractError(
            "server response exceeds the SDK safety limit",
            status_code=status_code,
            request_id=request_id,
        )
    content = bytearray()
    async for chunk in response.aiter_bytes():
        if len(content) + len(chunk) > MAX_RESPONSE_BYTES:
            status_code = response.status_code
            request_id = _safe_header_request_id(response)
            del chunk, content, response
            raise ContractError(
                "server response exceeds the SDK safety limit",
                status_code=status_code,
                request_id=request_id,
            )
        content.extend(chunk)
    return _detached_response(response, bytes(content))


def _oversized_content_length(response: httpx.Response) -> bool:
    value = response.headers.get("Content-Length")
    return bool(
        value is not None
        and value.isascii()
        and value.isdigit()
        and int(value) > MAX_RESPONSE_BYTES
    )


def _detached_response(response: httpx.Response, content: bytes) -> httpx.Response:
    safe_headers = {
        key: value
        for key, value in response.request.headers.items()
        if key.lower() != "authorization"
    }
    safe_request = httpx.Request(response.request.method, response.request.url, headers=safe_headers)
    return httpx.Response(
        response.status_code,
        headers=response.headers,
        content=content,
        request=safe_request,
    )


def _redact_response_request(response: httpx.Response) -> None:
    response.request.headers.pop("Authorization", None)


def _request_id(response: httpx.Response, parsed: BaseModel) -> str | None:
    header = response.headers.get("X-Request-ID")
    body = getattr(getattr(parsed, "meta", None), "request_id", None)
    direct = getattr(parsed, "request_id", None)
    request_id = body or direct
    if not isinstance(request_id, str) or not header or header != request_id:
        return None
    return str(request_id)


def _safe_header_request_id(response: httpx.Response) -> str | None:
    value = response.headers.get("X-Request-ID")
    if value is None or not 1 <= len(value) <= 128:
        return None
    if any(
        character not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._:-"
        for character in value
    ):
        return None
    return str(value)


def _can_retry_transport(
    method: str,
    attempt: int,
    config: ClientConfig,
    started: float,
    clock: Callable[[], float],
) -> bool:
    return (
        method.upper() in {"GET", "HEAD", "OPTIONS"}
        and attempt < config.retry.max_attempts
        and clock() - started < config.retry.max_elapsed
    )


def _can_retry_response(
    response: httpx.Response,
    method: str,
    attempt: int,
    config: ClientConfig,
    started: float,
    clock: Callable[[], float],
) -> bool:
    if response.status_code not in {429, 503} or not _can_retry_transport(
        method, attempt, config, started, clock
    ):
        return False
    payload = _safe_retry_payload(response)
    if payload is None:
        return False
    envelope, _ = _safe_validate(ErrorEnvelope, payload)
    if envelope is None:
        return False
    spec = ERROR_CONTRACT.get(envelope.error.code)
    return bool(
        isinstance(spec, dict)
        and spec["status"] == response.status_code
        and spec["retryable"] is True
        and envelope.error.retryable is True
    )


def _safe_retry_payload(response: httpx.Response) -> Any | None:
    payload, error = _json_payload(response)
    if error is not None:
        return None
    return payload


def _delay(attempt: int, config: ClientConfig, random_value: Callable[[], float]) -> float:
    base = min(config.retry.backoff_initial * (2 ** (attempt - 1)), config.retry.backoff_max)
    return float(min(base + random_value() * config.retry.jitter, config.retry.max_elapsed))


def _response_delay(
    response: httpx.Response,
    attempt: int,
    config: ClientConfig,
    random_value: Callable[[], float],
) -> float:
    retry_after = _retry_after(response)
    if retry_after is not None:
        return min(retry_after, config.retry.max_elapsed)
    return _delay(attempt, config, random_value)


def _bounded_delay(
    delay: float,
    started: float,
    config: ClientConfig,
    clock: Callable[[], float],
) -> float | None:
    remaining = config.retry.max_elapsed - (clock() - started)
    if delay > remaining:
        return None
    return max(0.0, delay)


def _retry_after(response: httpx.Response) -> float | None:
    value = response.headers.get("Retry-After")
    if value is None:
        return None
    if value.isascii() and value.isdigit():
        return float(value)
    try:
        target = email.utils.parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    if target.tzinfo is None:
        target = target.replace(tzinfo=UTC)
    return max(0.0, (target - datetime.now(UTC)).total_seconds())
