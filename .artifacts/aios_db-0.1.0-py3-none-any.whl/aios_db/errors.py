"""The error hierarchy of the ``aios-db`` primitives.

Every failure this library raises derives from :class:`AiosDbError`, so a
consumer can wrap a call site in one ``except`` without also swallowing
``psycopg`` errors it may want to handle differently (a serialization failure
worth retrying, say). Nothing here embeds a DSN, a host or a credential in its
message: these errors travel into logs and, through readiness probes, into
unauthenticated payloads.
"""

from __future__ import annotations


class AiosDbError(Exception):
    """Base class for every error raised by ``aios_db``."""


class PoolError(AiosDbError):
    """The connection pool could not be opened, or was used unopened."""


class AdvisoryLockError(AiosDbError):
    """An advisory lock could not be taken or released."""


class AdvisoryLockTimeout(AdvisoryLockError):
    """The wait for an advisory lock exceeded the caller's bound.

    Distinct from :class:`AdvisoryLockError` because it is the one advisory-lock
    failure a caller is expected to handle rather than propagate: a second
    migrator that cannot get the lock within its bound should report "another
    migration is running" and exit, not crash with an opaque driver error.
    """


class MigrationError(AiosDbError):
    """The migration set, or the database's record of it, is inconsistent."""


class MigrationChecksumMismatch(MigrationError):
    """An already-applied migration file differs from what was applied.

    Its own type because it is the one migration failure that indicates a
    *history* problem rather than a state problem: two environments can report
    the same schema version while holding different schemas.
    """
