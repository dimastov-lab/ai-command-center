from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from urllib.parse import urlsplit

import httpx

from ._version import __version__
from .errors import ConfigurationError

CredentialProvider = Callable[[], str]
_PROVIDER_FAILED = object()


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    max_attempts: int = 3
    max_elapsed: float = 30.0
    backoff_initial: float = 0.25
    backoff_max: float = 4.0
    jitter: float = 0.1

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ConfigurationError("max_attempts must be at least one")
        for name in ("max_elapsed", "backoff_initial", "backoff_max", "jitter"):
            if getattr(self, name) < 0:
                raise ConfigurationError(f"{name} must not be negative")
        if self.backoff_initial > self.backoff_max:
            raise ConfigurationError("backoff_initial must not exceed backoff_max")


@dataclass(frozen=True, slots=True, repr=False)
class ClientConfig:
    base_url: str
    token: str | None = field(default=None, repr=False)
    credential_provider: CredentialProvider | None = field(default=None, repr=False)
    timeout: httpx.Timeout = field(
        default_factory=lambda: httpx.Timeout(connect=5.0, read=30.0, write=30.0, pool=5.0)
    )
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    user_agent: str = field(default=f"aios-python-sdk/{__version__}")
    default_headers: Mapping[str, str] = field(default_factory=dict)
    verify: bool | str = True

    def __post_init__(self) -> None:
        value = self.base_url.strip()
        parsed = urlsplit(value)
        if not value or parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ConfigurationError("base_url must be an absolute HTTP or HTTPS URL")
        if parsed.username is not None or parsed.password is not None:
            raise ConfigurationError("base_url must not contain credentials")
        if parsed.query or parsed.fragment:
            raise ConfigurationError("base_url must not contain a query or fragment")
        if self.token is not None and self.credential_provider is not None:
            raise ConfigurationError("provide token or credential_provider, not both")
        if self.token is not None:
            _validate_token(self.token)
        headers = {str(key): str(item) for key, item in self.default_headers.items()}
        if any(key.lower() == "authorization" for key in headers):
            raise ConfigurationError("Authorization must be configured through credentials")
        if any("\r" in key or "\n" in key or "\r" in item or "\n" in item for key, item in headers.items()):
            raise ConfigurationError("default headers must not contain line breaks")
        if not self.user_agent.strip() or "\r" in self.user_agent or "\n" in self.user_agent:
            raise ConfigurationError("user_agent must be a safe non-empty value")
        object.__setattr__(self, "base_url", value.rstrip("/") + "/")
        object.__setattr__(self, "default_headers", MappingProxyType(headers))

    def __repr__(self) -> str:
        return (
            "ClientConfig("
            f"base_url={self.base_url!r}, timeout={self.timeout!r}, retry={self.retry!r}, "
            f"user_agent={self.user_agent!r}, verify={self.verify!r}, credentials=<redacted>)"
        )

    def authorization_value(self) -> str | None:
        token: str | None | object = self.token
        if self.credential_provider is not None:
            token = _call_credential_provider(self.credential_provider)
        if token is _PROVIDER_FAILED:
            raise ConfigurationError("credential provider failed")
        if token is None:
            return None
        assert isinstance(token, str)
        _validate_token(token)
        return f"Bearer {token}"


def _validate_token(token: str) -> None:
    if not isinstance(token, str) or not token.strip() or "\r" in token or "\n" in token:
        raise ConfigurationError("credential provider returned an invalid bearer token")


def _call_credential_provider(provider: CredentialProvider) -> str | object:
    try:
        return provider()
    except Exception:
        return _PROVIDER_FAILED
