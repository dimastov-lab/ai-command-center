"""Readiness primitives for a PostgreSQL dependency.

This module answers exactly one question -- *can this process reach the
database, and how quickly* -- and deliberately stops there. Whether the schema
is the version the build expects, whether a migration is mid-flight, whether the
answer means the process should receive traffic: those are compositions the
application owns, because only it knows what "ready" means for itself.

Liveness is likewise not here. A liveness probe that touches the database kills
every replica at the moment the database comes back, turning a recoverable
outage into a restart storm; a database library offering one would be offering a
mistake.

Two rules hold for everything this module returns. It never raises -- a probe
that raises is an outage reported as a crash -- and it never includes a DSN, a
host, a user or a driver message, because probe endpoints are commonly
unauthenticated. On failure the payload carries the exception's *type name* and
nothing else.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from .pool import pool_stats

if TYPE_CHECKING:  # pragma: no cover - import-time typing only
    import psycopg
    from psycopg_pool import ConnectionPool

__all__ = ["ProbeResult", "check_connectivity", "ping"]


@dataclass(frozen=True, slots=True)
class ProbeResult:
    """The outcome of a connectivity probe, safe to serialise to an open endpoint."""

    ok: bool
    latency_ms: float
    error: str | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "ok": self.ok,
            "latency_ms": self.latency_ms,
            **self.details,
        }
        if self.error is not None:
            payload["error"] = self.error
        return payload


def ping(conn: psycopg.Connection) -> None:
    """Round-trip the connection. Raises whatever the driver raises."""
    conn.execute("SELECT 1").fetchone()


def check_connectivity(pool: ConnectionPool) -> ProbeResult:
    """Check a connection out of ``pool``, round-trip it, and time the whole thing.

    The checkout is inside the measurement on purpose: a pool with every
    connection busy is not reachable from the caller's point of view, however
    healthy the server is, and a probe that measured only the query would report
    a saturated pool as ready.
    """
    started = time.perf_counter()
    try:
        with pool.connection() as conn:
            ping(conn)
    except Exception as exc:  # noqa: BLE001 - a probe reports failures, it does not raise
        return ProbeResult(
            ok=False,
            latency_ms=_elapsed_ms(started),
            # Type name only: driver messages carry host names and DSN fragments.
            error=type(exc).__name__,
        )

    latency_ms = _elapsed_ms(started)
    details: dict[str, Any] = {}
    try:
        details.update(pool_stats(pool))
    except Exception:  # noqa: BLE001 - counters are diagnostics, not the verdict
        pass
    return ProbeResult(ok=True, latency_ms=latency_ms, details=details)


def _elapsed_ms(started: float) -> float:
    return round((time.perf_counter() - started) * 1000, 2)
