"""Advisory-lock lifecycle.

PostgreSQL advisory locks are the mutual exclusion primitive for work that is
not a row or a table: running migrations, electing a single sweeper among
replicas, serialising a backfill. They are also easy to hold forever by
accident, because a *session*-level lock survives both a rollback and a pooled
connection's return to the pool -- the next checkout of that connection inherits
the lock and every later waiter blocks on a holder that no longer believes it
holds anything.

Everything here is therefore built around release. The session-level lock is a
context manager that unlocks on every exit path and refuses to run on a
connection whose transaction mode would make the unlock unreachable; the
transaction-level lock, for callers who are already inside a transaction, is
released by the database at commit or rollback and needs no unlock statement at
all.

Waiting is bounded through ``statement_timeout`` rather than ``lock_timeout``:
``pg_advisory_lock`` is a function call, so it is the *statement* timeout that
cancels a wait for one.
"""

from __future__ import annotations

import hashlib
import logging
import math
import re
from collections.abc import Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING

from ._session import is_autocommit, require_autocommit
from .errors import AdvisoryLockError, AdvisoryLockTimeout

if TYPE_CHECKING:  # pragma: no cover - import-time typing only
    import psycopg

__all__ = ["advisory_lock", "advisory_xact_lock", "lock_key", "try_advisory_lock"]

_LOG = logging.getLogger(__name__)

_INT64_MIN = -(2**63)
_INT64_MAX = 2**63 - 1


def lock_key(namespace: str) -> int:
    """Derive the stable 64-bit key for ``namespace``.

    Advisory locks share one flat key space per database, so two unrelated
    subsystems that both picked a hand-written constant can silently serialise
    against each other. Deriving the key from a name makes a collision as
    unlikely as a SHA-256 prefix collision and, unlike a constant in a header
    file, is impossible to copy into a second subsystem without also copying the
    name that explains it.
    """
    if not namespace:
        raise AdvisoryLockError("advisory-lock namespace must be a non-empty string")
    digest = hashlib.sha256(namespace.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big", signed=True)


def _validate_key(key: int) -> int:
    if not isinstance(key, int) or isinstance(key, bool):
        raise AdvisoryLockError("advisory-lock key must be an int")
    if not _INT64_MIN <= key <= _INT64_MAX:
        raise AdvisoryLockError("advisory-lock key must fit in a signed 64-bit integer")
    return key


def _require_autocommit(conn: psycopg.Connection) -> None:
    """Reject a connection whose transaction mode would strand the unlock.

    A failure inside the lock body would leave a non-autocommit session in
    ``InFailedSqlTransaction``, where the unlock statement fails too -- masking
    the original error and leaking a session-level lock that outlives the
    rollback. Callers already inside a transaction want
    :func:`advisory_xact_lock`, which the database releases for them.
    """
    require_autocommit(
        conn,
        "a session-level advisory lock requires an autocommit connection: on a "
        "non-autocommit connection a failure inside the lock leaves the session in "
        "a failed transaction, where the unlock cannot run and the lock leaks. Use "
        "advisory_xact_lock() to take a transaction-scoped lock instead.",
        AdvisoryLockError,
    )


def _read_statement_timeout(conn: psycopg.Connection) -> str:
    row = conn.execute("SHOW statement_timeout").fetchone()
    # `SHOW` always returns one row; the fallback keeps mypy and a hypothetical
    # driver quirk from turning restoration into an AttributeError.
    return "0" if row is None else str(row[0])


# A PostgreSQL time value: a bare integer (milliseconds) or an integer with a
# unit. `held_statement_timeout` is a public parameter of a published library,
# so its value is validated here *and* composed as a literal below. `SET` takes
# no bound parameters, and psycopg sends a parameterless statement over the
# simple query protocol, where a `;` in an interpolated value would start a
# second statement — under a connection that, for the migration runner, holds
# DDL rights.
_TIME_VALUE_RE = re.compile(r"^\d+\s*(us|ms|s|min|h|d)?$")


def _validate_time_value(value: str) -> str:
    """Validate and normalise a ``statement_timeout`` value.

    Called at function entry as well as at use, so a typo in a caller's argument
    fails before a lock is taken rather than mid-operation, after an acquire
    that then has to be undone.
    """
    normalized = value.strip()
    if not _TIME_VALUE_RE.match(normalized):
        raise AdvisoryLockError(
            f"invalid statement_timeout value {value!r}: expected an integer "
            "number of milliseconds, optionally with a unit (us/ms/s/min/h/d)"
        )
    return normalized


def _set_statement_timeout(conn: psycopg.Connection, value: str) -> None:
    from psycopg import sql

    conn.execute(
        sql.SQL("SET statement_timeout = {}").format(sql.Literal(_validate_time_value(value)))
    )


def _timeout_literal(seconds: float) -> str:
    if seconds <= 0:
        raise AdvisoryLockError("wait_timeout must be greater than zero seconds")
    # Round up: a sub-millisecond bound must not become `0`, which PostgreSQL
    # reads as "no timeout" -- the exact opposite of what the caller asked for.
    return f"{max(1, math.ceil(seconds * 1000))}ms"


@contextmanager
def advisory_lock(
    conn: psycopg.Connection,
    key: int,
    *,
    wait_timeout: float | None = None,
    held_statement_timeout: str | None = "0",
) -> Iterator[None]:
    """Hold the session-level advisory lock ``key`` for the duration of the block.

    ``wait_timeout`` bounds the acquisition. ``None`` waits indefinitely, which
    is what a migrator in a rolling deploy wants: the second one should queue
    behind the first, not fail. A caller that would rather report "busy" than
    queue passes a bound and handles :class:`~aios_db.errors.AdvisoryLockTimeout`.

    ``held_statement_timeout`` is the ``statement_timeout`` in force while the
    lock is held, defaulting to ``"0"`` (disabled) because the workloads that
    take an advisory lock -- a ``CREATE INDEX``, a backfill -- are exactly the
    ones a normal application statement timeout would kill halfway through, and
    identically so on every retry. Pass ``None`` to run the block under the
    session's own value: the bound used to *acquire* the lock is undone before
    the block runs, so a caller who asked for a 5s acquisition bound does not
    silently get a 5s bound on the work itself. The previous value is restored
    on exit either way.
    """
    key = _validate_key(key)
    _require_autocommit(conn)
    if held_statement_timeout is not None:
        # Validated before anything is acquired: a typo here should not cost an
        # acquire/release round trip and surface as a mid-operation failure.
        held_statement_timeout = _validate_time_value(held_statement_timeout)

    previous = _read_statement_timeout(conn)
    acquired = False
    block_failed = False
    try:
        _set_statement_timeout(
            conn, "0" if wait_timeout is None else _timeout_literal(wait_timeout)
        )
        try:
            conn.execute("SELECT pg_advisory_lock(%s)", (key,))
        except Exception as exc:
            if wait_timeout is not None and _is_query_canceled(exc):
                # `LockAcquire` can register the lock and only then process the
                # cancel interrupt, so a cancelled wait is not proof that
                # nothing was granted. An unlock we did not need returns false
                # and costs one round trip; a lock granted in that window and
                # never released would strand every later waiter on a pooled
                # connection that does not know it holds anything.
                _unlock_defensively(conn, key)
                raise AdvisoryLockTimeout(
                    f"could not acquire advisory lock {key} within {wait_timeout}s; "
                    "another session holds it"
                ) from exc
            raise
        acquired = True
        _set_statement_timeout(
            conn, previous if held_statement_timeout is None else held_statement_timeout
        )
        try:
            yield
        except BaseException:
            # An explicit flag, not the ambient `sys.exc_info()`: that is also
            # non-None when this lock was taken from inside an `except` handler,
            # and a failed release would then be swallowed while the caller went
            # on believing it held exclusion.
            block_failed = True
            raise
    finally:
        # Release first, restore second: the lock outlives the session setting
        # in consequence. Neither step may replace an exception already
        # propagating out of the caller's block -- that one explains what
        # happened, and a release error raised over it would bury it.
        try:
            if acquired:
                _unlock(conn, key, quiet=block_failed)
        finally:
            _restore_quietly(conn, previous)


@contextmanager
def try_advisory_lock(conn: psycopg.Connection, key: int) -> Iterator[bool]:
    """Take the session-level advisory lock ``key`` if it is free, without waiting.

    Yields whether the lock was taken. The block runs either way -- a
    single-sweeper election reads as ``if not held: return`` rather than as
    exception handling -- and the lock is released on exit only if this call is
    the one that took it.
    """
    key = _validate_key(key)
    _require_autocommit(conn)

    row = conn.execute("SELECT pg_try_advisory_lock(%s)", (key,)).fetchone()
    acquired = bool(row is not None and row[0])
    block_failed = False
    try:
        try:
            yield acquired
        except BaseException:
            block_failed = True
            raise
    finally:
        if acquired:
            _unlock(conn, key, quiet=block_failed)


@contextmanager
def advisory_xact_lock(
    conn: psycopg.Connection,
    key: int,
    *,
    wait_timeout: float | None = None,
) -> Iterator[None]:
    """Hold the transaction-level advisory lock ``key`` for the duration of the block.

    Released by PostgreSQL when the surrounding transaction commits or rolls
    back, so there is no unlock to reach and no way to leak the lock past the
    transaction -- the right primitive for a caller who is already inside one.
    The caller must be: on an autocommit connection with no open transaction the
    lock would be released the moment the acquiring statement completes, so this
    refuses to give a false sense of exclusion.
    """
    key = _validate_key(key)
    if is_autocommit(conn) and _is_idle(conn):
        raise AdvisoryLockError(
            "a transaction-level advisory lock needs an open transaction: on an "
            "idle autocommit connection it would be released immediately. Open one "
            "with conn.transaction(), or use advisory_lock() for a session-level lock."
        )
    if wait_timeout is None:
        conn.execute("SELECT pg_advisory_xact_lock(%s)", (key,))
        yield
        return

    previous = _read_statement_timeout(conn)
    try:
        _set_statement_timeout(conn, _timeout_literal(wait_timeout))
        try:
            conn.execute("SELECT pg_advisory_xact_lock(%s)", (key,))
        except Exception as exc:
            if _is_query_canceled(exc):
                raise AdvisoryLockTimeout(
                    f"could not acquire advisory lock {key} within {wait_timeout}s; "
                    "another session holds it"
                ) from exc
            raise
        _set_statement_timeout(conn, previous)
        yield
    finally:
        _restore_quietly(conn, previous)


def _unlock(conn: psycopg.Connection, key: int, *, quiet: bool = False) -> None:
    """Release the lock, reporting a release that finds nothing held.

    Postgres returns false when this session did not hold the lock: something
    released it out from under us, which invalidates the exclusion the caller
    just relied on. That is worth failing over -- unless the caller's own block
    already raised (``quiet``), in which case raising here would replace the
    error that actually explains the failure. A connection dropped inside the
    block produces exactly that pair. Then it is logged instead.
    """
    try:
        row = conn.execute("SELECT pg_advisory_unlock(%s)", (key,)).fetchone()
        released = bool(row is not None and row[0])
    except Exception:
        if quiet:
            _LOG.exception("failed to release advisory lock %s", key)
            return
        raise
    if not released:
        if quiet:
            _LOG.error("advisory lock %s was not held by this session at release time", key)
            return
        raise AdvisoryLockError(
            f"advisory lock {key} was not held by this session at release time"
        )


def _unlock_defensively(conn: psycopg.Connection, key: int) -> None:
    """Best-effort release for a lock we may or may not have been granted."""
    try:
        conn.execute("SELECT pg_advisory_unlock(%s)", (key,))
    except Exception:  # noqa: BLE001 - the acquisition error is the real one
        _LOG.debug("defensive advisory unlock of %s failed", key, exc_info=True)


def _restore_quietly(conn: psycopg.Connection, previous: str) -> None:
    """Restore ``statement_timeout``, never masking an in-flight exception.

    A pooled connection whose ``statement_timeout`` stayed at ``0`` would hand
    the next, unrelated checkout an unbounded timeout, so this is worth
    attempting even on the error path -- but a session already broken enough to
    reject a ``SET`` has a more informative failure on its way out.
    """
    try:
        _set_statement_timeout(conn, previous)
    except Exception:  # noqa: BLE001 - see docstring
        pass


def _is_query_canceled(exc: BaseException) -> bool:
    import psycopg

    return isinstance(exc, psycopg.errors.QueryCanceled)


def _is_idle(conn: psycopg.Connection) -> bool:
    """Whether the connection has no transaction open.

    ``psycopg`` is imported here rather than at module scope so this package
    stays importable -- for its pure-Python migration discovery and checksum
    verification -- on a machine with no driver installed.
    """
    import psycopg

    return conn.info.transaction_status == psycopg.pq.TransactionStatus.IDLE
