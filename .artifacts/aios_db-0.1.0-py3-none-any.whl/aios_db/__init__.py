"""``aios-db`` -- universal PostgreSQL primitives, packaged independently.

Four capabilities, and nothing above them:

* a **connection pool** whose open is verified before it is handed back;
* an **advisory-lock lifecycle** built around guaranteed release;
* **migration execution** that is serialised, atomic per migration,
  checksum-verified and reversible;
* a **readiness probe** that reports rather than raises, and leaks no DSN.

What is *not* here is the point of the package. It knows no tables, no roles, no
grants, no repositories and no backup policy: those are domain decisions that
belong to the application that owns the schema, and a shared library that
absorbed them would make every consumer's schema everyone else's business. The
distribution is versioned and pinned separately from the ``aios`` platform for
the same reason -- a consumer of these primitives should not inherit a platform
release cadence.

The primitives operate on ``psycopg`` connections and pools directly instead of
wrapping them in a facade: a consumer always ends up needing something the
facade did not forward, and a leaky facade is worse than none. ``psycopg`` is
imported lazily, so migration discovery and checksum verification work on a
machine with no driver installed.
"""

from __future__ import annotations

from ._version import __version__
from .advisory_lock import advisory_lock, advisory_xact_lock, lock_key, try_advisory_lock
from .contract import DB_CONTRACT, DbContract
from .errors import (
    AdvisoryLockError,
    AdvisoryLockTimeout,
    AiosDbError,
    MigrationChecksumMismatch,
    MigrationError,
    PoolError,
)
from .health import ProbeResult, check_connectivity, ping
from .migrations import DEFAULT_LEDGER_TABLE, Migration, MigrationRunner, discover
from .pool import connection, open_pool, pool_stats

__all__ = [
    "DB_CONTRACT",
    "DEFAULT_LEDGER_TABLE",
    "AdvisoryLockError",
    "AdvisoryLockTimeout",
    "AiosDbError",
    "DbContract",
    "Migration",
    "MigrationChecksumMismatch",
    "MigrationError",
    "MigrationRunner",
    "PoolError",
    "ProbeResult",
    "__version__",
    "advisory_lock",
    "advisory_xact_lock",
    "check_connectivity",
    "connection",
    "discover",
    "lock_key",
    "open_pool",
    "ping",
    "pool_stats",
    "try_advisory_lock",
]
