"""Stable metadata for consumers of the separately packaged ``aios-db`` library.

A consumer that vendors a wheel needs to assert, at install-verification time,
that the artifact it just installed is the distribution it meant to pin and that
it still provides the capabilities the consumer builds on. Both facts are
declared here rather than inferred from a version number.
"""

from __future__ import annotations

from dataclasses import dataclass

from ._version import __version__

__all__ = ["DB_CONTRACT", "DbContract"]


@dataclass(frozen=True, slots=True)
class DbContract:
    distribution: str
    version: str
    capabilities: frozenset[str]
    # Facts this library deliberately does not provide. Named so a consumer
    # cannot mistake their absence for an oversight and go looking for them in
    # the platform package, which is exactly the boundary crossing this
    # distribution exists to prevent.
    out_of_scope: tuple[str, ...]


DB_CONTRACT = DbContract(
    distribution="aios-db",
    version=__version__,
    capabilities=frozenset(
        {
            "connection_pool",
            "advisory_lock",
            "migration_execution",
            "readiness_probe",
        }
    ),
    out_of_scope=(
        "domain_schema",
        "database_roles_and_grants",
        "repositories",
        "backup_and_restore",
    ),
)
