"""Session-mode preconditions shared by the advisory-lock and migration primitives."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover - import-time typing only
    import psycopg


def is_autocommit(conn: psycopg.Connection) -> bool:
    return bool(getattr(conn, "autocommit", False))


def require_autocommit(conn: psycopg.Connection, message: str, error: type[Exception]) -> None:
    """Raise ``error`` unless ``conn`` is in autocommit mode.

    Both callers depend on the same underlying fact: on a non-autocommit
    connection psycopg opens an implicit transaction before the first statement,
    so ``conn.transaction()`` degrades to a mere ``SAVEPOINT``, nothing is
    durable until someone remembers to commit, and a failure leaves the session
    in ``InFailedSqlTransaction`` -- where the cleanup statement (an unlock, a
    ledger write) fails too and masks the original error.
    """
    if not is_autocommit(conn):
        raise error(message)
