from __future__ import annotations

from collections.abc import AsyncIterator, Awaitable, Callable, Iterator
from dataclasses import dataclass
from typing import Generic, TypeVar

from .errors import ContractError

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class Page(Generic[T]):
    items: tuple[T, ...]
    next_cursor: str | None
    has_more: bool
    request_id: str
    status_code: int


def iterate_pages(first: Callable[[str | None], Page[T]]) -> Iterator[T]:
    cursor: str | None = None
    seen: set[str] = set()
    while True:
        page = first(cursor)
        yield from page.items
        if not page.has_more:
            return
        if page.next_cursor is None or page.next_cursor in seen:
            raise ContractError("server returned a missing or repeated pagination cursor")
        seen.add(page.next_cursor)
        cursor = page.next_cursor


async def iterate_pages_async(
    first: Callable[[str | None], Awaitable[Page[T]]],
) -> AsyncIterator[T]:
    cursor: str | None = None
    seen: set[str] = set()
    while True:
        page = await first(cursor)
        for item in page.items:
            yield item
        if not page.has_more:
            return
        if page.next_cursor is None or page.next_cursor in seen:
            raise ContractError("server returned a missing or repeated pagination cursor")
        seen.add(page.next_cursor)
        cursor = page.next_cursor
