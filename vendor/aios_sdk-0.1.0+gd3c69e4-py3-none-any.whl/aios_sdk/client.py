from __future__ import annotations

import traceback
import uuid
from collections.abc import Iterator, Mapping
from functools import wraps
from typing import Any, Callable, ParamSpec, TypeVar, cast
from urllib.parse import quote

import httpx

from .config import ClientConfig, CredentialProvider, RetryPolicy
from .errors import ContractError
from .generated.models import (
    CreateMemoryRequest,
    CreateTaskRequest,
    HealthStatus,
    MemoryObject,
    MemoryObjectListResponse,
    MemoryObjectResponse,
    ReadinessStatus,
    Task,
    TaskAssigneeRequest,
    TaskEvent,
    TaskEventListResponse,
    TaskListResponse,
    TaskResponse,
    TaskSweepResponse,
    Workspace,
    WorkspaceCreateRequest,
    WorkspaceListResponse,
    WorkspaceResponse,
)
from .pagination import Page, iterate_pages
from .transport import APIResponse, SyncTransport, parse_success, raise_for_error

P = ParamSpec("P")
R = TypeVar("R")


def _contract_boundary(method: Callable[P, R]) -> Callable[P, R]:
    @wraps(method)
    def guarded(*args: P.args, **kwargs: P.kwargs) -> R:
        safe_error: ContractError | None = None
        try:
            return method(*args, **kwargs)
        except ContractError as error:
            if error.__traceback__ is not None:
                traceback.clear_frames(error.__traceback__)
            safe_error = ContractError(
                str(error),
                status_code=error.status_code,
                request_id=error.request_id,
                code=error.code,
                validation_summary=error.validation_summary,
            )
        assert safe_error is not None
        raise safe_error

    return cast(Callable[P, R], guarded)


class WorkspacesAPI:
    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    @_contract_boundary
    def create(
        self, request: WorkspaceCreateRequest, *, request_id: str | None = None
    ) -> APIResponse[Workspace]:
        response = self._transport.request(
            "POST",
            "/api/v1/workspaces",
            auth=True,
            json=request.model_dump(mode="json", exclude_none=True),
            request_id=request_id,
        )
        _expect(response, {201})
        wrapped = parse_success(response, WorkspaceResponse)
        return APIResponse(
            wrapped.data.data,
            wrapped.request_id,
            wrapped.status_code,
            wrapped.etag,
            wrapped.retry_after,
        )

    @_contract_boundary
    def get(self, workspace_id: str, *, request_id: str | None = None) -> APIResponse[Workspace]:
        response = self._transport.request(
            "GET",
            f"/api/v1/workspaces/{_path_id(workspace_id)}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        wrapped = parse_success(response, WorkspaceResponse)
        return APIResponse(
            wrapped.data.data,
            wrapped.request_id,
            wrapped.status_code,
            wrapped.etag,
            wrapped.retry_after,
        )

    @_contract_boundary
    def list(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        request_id: str | None = None,
    ) -> Page[Workspace]:
        _page_arguments(limit, cursor)
        params: dict[str, str | int | float | bool | None] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        response = self._transport.request(
            "GET",
            "/api/v1/workspaces",
            auth=True,
            params=params,
            request_id=request_id,
        )
        _expect(response, {200})
        wrapped = parse_success(response, WorkspaceListResponse)
        return Page(
            wrapped.data.data,
            wrapped.data.page.next_cursor,
            wrapped.data.page.has_more,
            wrapped.request_id,
            wrapped.status_code,
        )

    def iterate(self, *, limit: int = 50, request_id: str | None = None) -> Iterator[Workspace]:
        _page_arguments(limit, None)
        return iterate_pages(
            lambda cursor: self.list(limit=limit, cursor=cursor, request_id=request_id)
        )


class MemoriesAPI:
    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    @_contract_boundary
    def create_in_workspace(
        self,
        workspace_id: str,
        request: CreateMemoryRequest,
        *,
        idempotency_key: str | None = None,
        request_id: str | None = None,
    ) -> APIResponse[MemoryObject]:
        response = self._transport.request(
            "POST",
            f"/api/v1/workspaces/{_path_id(workspace_id)}/memories",
            auth=True,
            json=request.model_dump(mode="json", exclude_none=True),
            extra_headers=_idempotency_headers(idempotency_key),
            request_id=request_id,
        )
        _expect(response, {200, 201})
        return _memory_result(response)

    @_contract_boundary
    def create_global(
        self,
        request: CreateMemoryRequest,
        *,
        idempotency_key: str | None = None,
        request_id: str | None = None,
    ) -> APIResponse[MemoryObject]:
        response = self._transport.request(
            "POST",
            "/api/v1/global/memories",
            auth=True,
            json=request.model_dump(mode="json", exclude_none=True),
            extra_headers=_idempotency_headers(idempotency_key),
            request_id=request_id,
        )
        _expect(response, {200, 201})
        return _memory_result(response)

    @_contract_boundary
    def get_in_workspace(
        self, workspace_id: str, memory_id: str, *, request_id: str | None = None
    ) -> APIResponse[MemoryObject]:
        response = self._transport.request(
            "GET",
            f"/api/v1/workspaces/{_path_id(workspace_id)}/memories/{_path_id(memory_id)}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        return _memory_result(response)

    @_contract_boundary
    def get_global(
        self, memory_id: str, *, request_id: str | None = None
    ) -> APIResponse[MemoryObject]:
        response = self._transport.request(
            "GET",
            f"/api/v1/global/memories/{_path_id(memory_id)}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        return _memory_result(response)

    @_contract_boundary
    def list_in_workspace(
        self,
        workspace_id: str,
        *,
        limit: int = 50,
        cursor: str | None = None,
        kind: str | None = None,
        status: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        text: str | None = None,
        order: str | None = None,
        include_global: bool | None = None,
        request_id: str | None = None,
    ) -> Page[MemoryObject]:
        _page_arguments(limit, cursor)
        params = _memory_query_params(
            limit=limit,
            cursor=cursor,
            kind=kind,
            status=status,
            created_after=created_after,
            created_before=created_before,
            text=text,
            order=order,
        )
        if include_global is not None:
            params["include_global"] = include_global
        response = self._transport.request(
            "GET",
            f"/api/v1/workspaces/{_path_id(workspace_id)}/memories",
            auth=True,
            params=params,
            request_id=request_id,
        )
        _expect(response, {200})
        return _memory_page(response)

    @_contract_boundary
    def list_global(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        kind: str | None = None,
        status: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        text: str | None = None,
        order: str | None = None,
        request_id: str | None = None,
    ) -> Page[MemoryObject]:
        _page_arguments(limit, cursor)
        params = _memory_query_params(
            limit=limit,
            cursor=cursor,
            kind=kind,
            status=status,
            created_after=created_after,
            created_before=created_before,
            text=text,
            order=order,
        )
        response = self._transport.request(
            "GET",
            "/api/v1/global/memories",
            auth=True,
            params=params,
            request_id=request_id,
        )
        _expect(response, {200})
        return _memory_page(response)


class TasksAPI:
    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    @_contract_boundary
    def create(
        self,
        request: CreateTaskRequest,
        *,
        idempotency_key: str | None = None,
        request_id: str | None = None,
    ) -> APIResponse[Task]:
        response = self._transport.request(
            "POST",
            "/api/v1/tasks",
            auth=True,
            json=request.model_dump(mode="json", exclude_none=True),
            extra_headers=_idempotency_headers(idempotency_key),
            request_id=request_id,
        )
        # 201 = created, 200 = idempotent replay of the original task --
        # callers distinguish via `status_code`, as with memory creates.
        _expect(response, {200, 201})
        return _task_result(response)

    @_contract_boundary
    def get(self, task_id: str, *, request_id: str | None = None) -> APIResponse[Task]:
        response = self._transport.request(
            "GET",
            f"/api/v1/tasks/{_path_id(task_id)}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        return _task_result(response)

    @_contract_boundary
    def list(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        request_id: str | None = None,
    ) -> Page[Task]:
        _page_arguments(limit, cursor)
        params: dict[str, str | int | float | bool | None] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        response = self._transport.request(
            "GET",
            "/api/v1/tasks",
            auth=True,
            params=params,
            request_id=request_id,
        )
        _expect(response, {200})
        return _task_page(response)

    def iterate(self, *, limit: int = 50, request_id: str | None = None) -> Iterator[Task]:
        _page_arguments(limit, None)
        return iterate_pages(
            lambda cursor: self.list(limit=limit, cursor=cursor, request_id=request_id)
        )

    @_contract_boundary
    def list_events(
        self, task_id: str, *, request_id: str | None = None
    ) -> APIResponse[tuple[TaskEvent, ...]]:
        response = self._transport.request(
            "GET",
            f"/api/v1/tasks/{_path_id(task_id)}/events",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        wrapped = parse_success(response, TaskEventListResponse)
        return APIResponse(
            wrapped.data.data,
            wrapped.request_id,
            wrapped.status_code,
            wrapped.etag,
            wrapped.retry_after,
        )

    @_contract_boundary
    def assign(
        self, task_id: str, assignee: str, *, request_id: str | None = None
    ) -> APIResponse[Task]:
        return self._assignee_action(task_id, "assign", assignee, request_id)

    @_contract_boundary
    def reassign(
        self, task_id: str, assignee: str, *, request_id: str | None = None
    ) -> APIResponse[Task]:
        return self._assignee_action(task_id, "reassign", assignee, request_id)

    @_contract_boundary
    def start(self, task_id: str, *, request_id: str | None = None) -> APIResponse[Task]:
        return self._action(task_id, "start", request_id)

    @_contract_boundary
    def complete(self, task_id: str, *, request_id: str | None = None) -> APIResponse[Task]:
        return self._action(task_id, "complete", request_id)

    @_contract_boundary
    def cancel(self, task_id: str, *, request_id: str | None = None) -> APIResponse[Task]:
        return self._action(task_id, "cancel", request_id)

    @_contract_boundary
    def escalate(self, task_id: str, *, request_id: str | None = None) -> APIResponse[Task]:
        return self._action(task_id, "escalate", request_id)

    @_contract_boundary
    def sweep_due(self, *, request_id: str | None = None) -> APIResponse[tuple[Task, ...]]:
        response = self._transport.request(
            "POST",
            "/api/v1/tasks/sweep-due",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        wrapped = parse_success(response, TaskSweepResponse)
        return APIResponse(
            wrapped.data.data,
            wrapped.request_id,
            wrapped.status_code,
            wrapped.etag,
            wrapped.retry_after,
        )

    def _action(self, task_id: str, action: str, request_id: str | None) -> APIResponse[Task]:
        response = self._transport.request(
            "POST",
            f"/api/v1/tasks/{_path_id(task_id)}/{action}",
            auth=True,
            request_id=request_id,
        )
        _expect(response, {200})
        return _task_result(response)

    def _assignee_action(
        self, task_id: str, action: str, assignee: str, request_id: str | None
    ) -> APIResponse[Task]:
        body = TaskAssigneeRequest(assignee=assignee)
        response = self._transport.request(
            "POST",
            f"/api/v1/tasks/{_path_id(task_id)}/{action}",
            auth=True,
            json=body.model_dump(mode="json"),
            request_id=request_id,
        )
        _expect(response, {200})
        return _task_result(response)


class HealthAPI:
    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    @_contract_boundary
    def get(self, *, request_id: str | None = None) -> APIResponse[HealthStatus]:
        response = self._transport.request(
            "GET", "/healthz", auth=False, request_id=request_id
        )
        _expect(response, {200})
        return parse_success(response, HealthStatus)


class ReadinessAPI:
    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    @_contract_boundary
    def get(self, *, request_id: str | None = None) -> APIResponse[ReadinessStatus]:
        response = self._transport.request("GET", "/readyz", auth=False, request_id=request_id)
        _expect(response, {200, 503}, error_statuses={500})
        return parse_success(response, ReadinessStatus)


class AIOSClient:
    def __init__(
        self,
        base_url: str,
        *,
        token: str | None = None,
        credential_provider: CredentialProvider | None = None,
        timeout: httpx.Timeout | None = None,
        retry: RetryPolicy | None = None,
        user_agent: str | None = None,
        default_headers: Mapping[str, str] | None = None,
        verify: bool | str = True,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        config_kwargs: dict[str, Any] = {
            "base_url": base_url,
            "token": token,
            "credential_provider": credential_provider,
            "verify": verify,
        }
        if timeout is not None:
            config_kwargs["timeout"] = timeout
        if retry is not None:
            config_kwargs["retry"] = retry
        if user_agent is not None:
            config_kwargs["user_agent"] = user_agent
        if default_headers is not None:
            config_kwargs["default_headers"] = default_headers
        self.config = ClientConfig(**config_kwargs)
        self._transport = SyncTransport(self.config, transport=transport)
        self.workspaces = WorkspacesAPI(self._transport)
        self.memories = MemoriesAPI(self._transport)
        self.tasks = TasksAPI(self._transport)
        self.health = HealthAPI(self._transport)
        self.readiness = ReadinessAPI(self._transport)

    @property
    def is_closed(self) -> bool:
        return self._transport.is_closed

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> AIOSClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


def _expect(
    response: httpx.Response,
    success_statuses: set[int],
    *,
    error_statuses: set[int] | None = None,
) -> None:
    if response.status_code in success_statuses:
        return
    if error_statuses is None or response.status_code in error_statuses or response.status_code >= 400:
        raise_for_error(response)
    raise ContractError("server returned an undocumented HTTP status")


def _page_arguments(limit: int, cursor: str | None) -> None:
    if not 1 <= limit <= 200:
        raise ContractError("limit must be between 1 and 200")
    if cursor is not None and not 1 <= len(cursor) <= 4096:
        raise ContractError("cursor must contain between 1 and 4096 characters")


def _path_id(value: str) -> str:
    if not 1 <= len(value) <= 255:
        raise ContractError("workspace_id must contain between 1 and 255 characters")
    return quote(value, safe="")


def _task_result(response: httpx.Response) -> APIResponse[Task]:
    wrapped = parse_success(response, TaskResponse)
    return APIResponse(
        wrapped.data.data,
        wrapped.request_id,
        wrapped.status_code,
        wrapped.etag,
        wrapped.retry_after,
    )


def _task_page(response: httpx.Response) -> Page[Task]:
    wrapped = parse_success(response, TaskListResponse)
    return Page(
        wrapped.data.data,
        wrapped.data.page.next_cursor,
        wrapped.data.page.has_more,
        wrapped.request_id,
        wrapped.status_code,
    )


def _memory_result(response: httpx.Response) -> APIResponse[MemoryObject]:
    wrapped = parse_success(response, MemoryObjectResponse)
    return APIResponse(
        wrapped.data.data,
        wrapped.request_id,
        wrapped.status_code,
        wrapped.etag,
        wrapped.retry_after,
    )


def _memory_page(response: httpx.Response) -> Page[MemoryObject]:
    wrapped = parse_success(response, MemoryObjectListResponse)
    return Page(
        wrapped.data.data,
        wrapped.data.page.next_cursor,
        wrapped.data.page.has_more,
        wrapped.request_id,
        wrapped.status_code,
    )


def _memory_query_params(
    *,
    limit: int,
    cursor: str | None,
    kind: str | None,
    status: str | None,
    created_after: str | None,
    created_before: str | None,
    text: str | None,
    order: str | None,
) -> dict[str, str | int | float | bool | None]:
    params: dict[str, str | int | float | bool | None] = {"limit": limit}
    optional: dict[str, str | None] = {
        "cursor": cursor,
        "kind": kind,
        "status": status,
        "created_after": created_after,
        "created_before": created_before,
        "text": text,
        "order": order,
    }
    for name, value in optional.items():
        if value is not None:
            params[name] = value
    return params


def _idempotency_headers(idempotency_key: str | None) -> dict[str, str]:
    # The server requires an `Idempotency-Key` on memory creates. When the caller
    # does not supply one, generate a fresh key per call: create then works out of
    # the box and stays idempotent across this call's transport retries (the same
    # key is reused for every retry attempt). uuid4 hex satisfies the server's
    # `^[A-Za-z0-9._:-]{1,255}$` constraint.
    key = idempotency_key if idempotency_key is not None else uuid.uuid4().hex
    return {"Idempotency-Key": key}
