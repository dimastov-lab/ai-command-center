from __future__ import annotations

from typing import Any

from .generated.models import ErrorDetails


class AIOSSDKError(Exception):
    """Base class for safe SDK errors."""


class ConfigurationError(AIOSSDKError, ValueError):
    pass


class TransportError(AIOSSDKError):
    pass


class TimeoutError(TransportError):
    pass


class ContractError(AIOSSDKError):
    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        request_id: str | None = None,
        code: str | None = None,
        validation_summary: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.request_id = request_id
        self.code = code
        self.validation_summary = validation_summary

    def __repr__(self) -> str:
        return (
            f"ContractError(status_code={self.status_code!r}, request_id={self.request_id!r}, "
            f"code={self.code!r}, validation_summary={self.validation_summary!r})"
        )


class APIError(AIOSSDKError):
    def __init__(
        self,
        *,
        status_code: int,
        code: str,
        message: str,
        request_id: str,
        retryable: bool,
        details: ErrorDetails | None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(f"{code}: {message} (request_id={request_id})")
        self.status_code = status_code
        self.code = code
        self.safe_message = message
        self.request_id = request_id
        self.retryable = retryable
        self.details = details
        self.retry_after = retry_after

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}(status_code={self.status_code!r}, code={self.code!r}, "
            f"request_id={self.request_id!r}, retryable={self.retryable!r})"
        )


class AuthenticationError(APIError):
    pass


class AuthorizationError(APIError):
    pass


class NotFoundError(APIError):
    pass


class ConflictError(APIError):
    pass


class RevisionConflictError(APIError):
    pass


class ValidationError(APIError):
    pass


class RateLimitError(APIError):
    pass


class ServiceUnavailableError(APIError):
    pass


class InternalServerError(APIError):
    pass


_CODE_ERRORS: dict[str, type[APIError]] = {
    "unauthorized": AuthenticationError,
    "forbidden": AuthorizationError,
    "resource_not_found": NotFoundError,
    "conflict": ConflictError,
    "idempotency_conflict": ConflictError,
    "operator_action_refused": ConflictError,
    "revision_conflict": RevisionConflictError,
    "invalid_request": ValidationError,
    "invalid_cursor": ValidationError,
    "invalid_precondition": ValidationError,
    "request_too_large": ValidationError,
    "unsupported_media_type": ValidationError,
    "validation_failed": ValidationError,
    "invalid_transition": ValidationError,
    "invalid_idempotency_key": ValidationError,
    "precondition_required": ValidationError,
    "rate_limited": RateLimitError,
    "unsupported_storage_schema": ServiceUnavailableError,
    "storage_corrupted": ServiceUnavailableError,
    "service_unavailable": ServiceUnavailableError,
    "internal_error": InternalServerError,
}


def exception_type(code: str) -> type[APIError]:
    error_type = _CODE_ERRORS.get(code)
    if error_type is None:
        raise ContractError("server returned an unknown canonical error code")
    return error_type


def safe_hook_headers(headers: Any) -> dict[str, str]:
    """Return headers suitable for diagnostics without credential disclosure."""
    return {
        str(key): "<redacted>" if str(key).lower() == "authorization" else str(value)
        for key, value in headers.items()
    }
